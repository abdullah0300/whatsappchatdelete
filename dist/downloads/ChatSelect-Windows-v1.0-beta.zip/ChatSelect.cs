using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace ChatSelectApp {
    static class Program {
        [STAThread] static void Main(string[] args) {
            bool first;
            using (var instance = new Mutex(true, "Local\\ChatSelect.Windows.Launcher", out first)) {
                if (!first) { MessageBox.Show("ChatSelect is already open. Return to that window to continue.", "ChatSelect"); return; }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
        }
    }

    sealed class MainForm : Form {
        static readonly Color Ink=Color.FromArgb(23,48,39), Green=Color.FromArgb(25,111,74), Muted=Color.FromArgb(96,112,104), Paper=Color.FromArgb(247,249,245);
        NumericUpDown count;
        ComboBox speed;
        Button start,pause,stop;
        Label status,number,elapsed,phase;
        ProgressBar progress;
        Process worker;
        string session="", lastPhase="", lastMessage="";
        double activeSeconds;
        DateTime updatedAt;
        System.Windows.Forms.Timer poll;
        bool closing;
        JavaScriptSerializer json=new JavaScriptSerializer();
        public MainForm() {
            Text="ChatSelect for Windows"; BackColor=Paper; ForeColor=Ink;
            Font=new Font("Segoe UI",11); AutoScaleDimensions=new SizeF(96,96); AutoScaleMode=AutoScaleMode.Dpi;
            ClientSize=new Size(620,746); FormBorderStyle=FormBorderStyle.FixedSingle;
            MaximizeBox=false; StartPosition=FormStartPosition.CenterScreen;
            Label brand=LabelAt("ChatSelect",28,22,400,46,29,FontStyle.Bold);
            var beta=LabelAt("WINDOWS BETA",445,34,150,24,9,FontStyle.Bold); beta.ForeColor=Green;
            LabelAt("Select your messages. Keep your time.",30,78,555,28,12,FontStyle.Regular).ForeColor=Muted;
            var divider=new Panel { Location=new Point(30,121),Size=new Size(560,1),BackColor=Color.FromArgb(220,228,218) }; Controls.Add(divider);
            LabelAt("How many messages?",30,145,550,30,16,FontStyle.Bold);
            var inputPanel=new Panel { Location=new Point(30,187),Size=new Size(560,67),BackColor=Color.White,BorderStyle=BorderStyle.FixedSingle }; Controls.Add(inputPanel);
            count=new NumericUpDown { Location=new Point(15,10),Size=new Size(525,48),Minimum=1,Maximum=10000,Value=1000,ThousandsSeparator=true,Font=new Font("Segoe UI",25,FontStyle.Bold),BorderStyle=BorderStyle.None,ForeColor=Ink,BackColor=Color.White,AccessibleName="Number of new messages" }; inputPanel.Controls.Add(count);
            LabelAt("New selections only. Already selected messages are skipped.",30,263,560,25,10,FontStyle.Regular).ForeColor=Muted;
            LabelAt("Selection speed",30,307,240,26,12,FontStyle.Bold);
            speed=new ComboBox { Location=new Point(30,341),Size=new Size(275,32),DropDownStyle=ComboBoxStyle.DropDownList,Font=new Font("Segoe UI",12),AccessibleName="Selection speed" };
            speed.Items.AddRange(new object[]{"Quick (recommended)","Gentle"}); speed.SelectedIndex=0; Controls.Add(speed);
            var guide=ButtonAt("How to use",327,339,263,36,false); guide.Click+=delegate { new GuideForm().Show(); };
            start=ButtonAt("Start setup",30,401,560,48,true); start.Click+=StartSession;
            var hint=LabelAt("Then switch to WhatsApp and follow F6 > F7 > F8.",30,458,560,26,10,FontStyle.Regular); hint.ForeColor=Muted;
            var card=new Panel { Location=new Point(30,502),Size=new Size(560,155),BackColor=Color.White,BorderStyle=BorderStyle.FixedSingle }; Controls.Add(card);
            phase=new Label { Text="READY WHEN YOU ARE",Location=new Point(16,12),Size=new Size(520,20),Font=new Font("Segoe UI",9,FontStyle.Bold),ForeColor=Green }; card.Controls.Add(phase);
            number=new Label { Text="0 selected",Location=new Point(16,34),Size=new Size(340,34),Font=new Font("Segoe UI",18,FontStyle.Bold),ForeColor=Ink }; card.Controls.Add(number);
            elapsed=new Label { Text="00:00",TextAlign=ContentAlignment.MiddleRight,Location=new Point(385,39),Size=new Size(150,25),ForeColor=Muted }; card.Controls.Add(elapsed);
            progress=new ProgressBar { Location=new Point(18,77),Size=new Size(518,8),Minimum=0,Maximum=1000,Style=ProgressBarStyle.Continuous }; card.Controls.Add(progress);
            status=new Label { Text="Choose a count, then start setup. No messages are selected yet.",Location=new Point(16,101),Size=new Size(522,42),Font=new Font("Segoe UI",10),ForeColor=Muted }; card.Controls.Add(status);
            pause=ButtonAt("Pause",30,673,175,37,false); pause.Enabled=false;
            pause.Click+=delegate { if(session!="") File.WriteAllText(Path.Combine(session,"pause.request"),""); };
            stop=ButtonAt("End session",218,673,175,37,false); stop.Enabled=false; stop.Click+=delegate { EndSession(); };
            LabelAt("F8 pauses   /   F9 exits",407,680,190,22,9,FontStyle.Regular).ForeColor=Muted;
            poll=new System.Windows.Forms.Timer { Interval=250 }; poll.Tick+=PollState; poll.Start();
            FormClosing+=delegate { closing=true; EndSession(); poll.Stop(); };
        }
        Label LabelAt(string text,int x,int y,int w,int h,float size,FontStyle style) {
            var l=new Label { Text=text,Location=new Point(x,y),Size=new Size(w,h),Font=new Font("Segoe UI",size,style),ForeColor=Ink }; Controls.Add(l); return l;
        }
        Button ButtonAt(string text,int x,int y,int w,int h,bool primary) {
            var b=new Button { Text=text,Location=new Point(x,y),Size=new Size(w,h),FlatStyle=FlatStyle.Flat,BackColor=primary?Green:Color.White,ForeColor=primary?Color.White:Ink,Font=new Font("Segoe UI",11,FontStyle.Bold),Cursor=Cursors.Hand,UseVisualStyleBackColor=false };
            b.FlatAppearance.BorderColor=primary?Green:Color.FromArgb(213,223,211); Controls.Add(b); return b;
        }
        void StartSession(object sender,EventArgs e) {
            if(worker!=null && !worker.HasExited) return;
            string engine=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Selector.Engine.ps1");
            if(!File.Exists(engine)) { MessageBox.Show("Extract the entire ZIP into one folder before opening ChatSelect.","Missing file"); return; }
            session=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ChatSelect","Sessions",DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6));
            Directory.CreateDirectory(session);
            int target=(int)count.Value,gap=speed.SelectedIndex==0?35:70;
            string args="-NoProfile -ExecutionPolicy Bypass -File \""+engine+"\" -TargetCount "+target+" -ClickGapMs "+gap+" -SessionDirectory \""+session+"\"";
            try {
                worker=new Process();
                worker.StartInfo=new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),@"WindowsPowerShell\v1.0\powershell.exe"),args) { UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory };
                worker.Start();
                start.Enabled=false; count.Enabled=false; speed.Enabled=false; pause.Enabled=true; stop.Enabled=true;
                start.Text="Setup is open - switch to WhatsApp";
                phase.Text="SET UP YOUR CHAT"; status.Text="Open WhatsApp in Select messages mode. Point at an empty checkbox and press F6.";
                number.Text="0 / "+target.ToString("N0")+" selected"; progress.Maximum=target; progress.Value=0;
                lastPhase="setup"; lastMessage=""; activeSeconds=0; elapsed.Text="00:00";
            } catch(Exception ex) { MessageBox.Show("ChatSelect could not start. "+ex.Message,"Unable to start"); }
        }
        void PollState(object sender,EventArgs e) {
            if(session=="") return;
            string path=Path.Combine(session,"state.json");
            if(File.Exists(path)) {
                try {
                    string stateText;
                    using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
                    using(var reader=new StreamReader(stream)) stateText=reader.ReadToEnd();
                    var state=json.Deserialize<Dictionary<string,object>>(stateText);
                    lastPhase=Convert.ToString(state["Phase"]); lastMessage=Convert.ToString(state["Message"]);
                    int selected=Convert.ToInt32(state["Selected"]),target=Convert.ToInt32(state["Target"]);
                    number.Text=selected.ToString("N0")+" / "+target.ToString("N0")+" selected";
                    progress.Maximum=Math.Max(1,target); progress.Value=Math.Min(progress.Maximum,selected);
                    activeSeconds=Convert.ToDouble(state["ActiveSeconds"]);
                    updatedAt=DateTime.Parse(Convert.ToString(state["UpdatedAt"])).ToUniversalTime();
                    phase.Text=PhaseTitle(lastPhase); status.Text=lastMessage;
                    if(lastPhase=="complete") { pause.Enabled=false; start.Text="Finish this session to choose a new count"; }
                } catch(IOException) {} catch(ArgumentException) {} catch(InvalidOperationException) {} catch(KeyNotFoundException) {}
            }
            double seconds=activeSeconds;
            if(lastPhase=="selecting" || lastPhase=="loading" || lastPhase=="recovering") seconds+=Math.Max(0,(DateTime.UtcNow-updatedAt).TotalSeconds);
            var time=TimeSpan.FromSeconds(Math.Max(0,seconds));
            elapsed.Text=((int)time.TotalMinutes).ToString("00")+":"+time.Seconds.ToString("00");
            if(worker!=null && worker.HasExited) {
                worker.Dispose(); worker=null;
                start.Enabled=true; start.Text="Start a new session"; count.Enabled=true; speed.Enabled=true; pause.Enabled=false; stop.Enabled=false;
                if(lastPhase!="complete" && lastPhase!="stopped") { phase.Text="SESSION ENDED"; status.Text="The session ended. Reopen setup to try again."; lastPhase="stopped"; }
            }
        }
        static string PhaseTitle(string p) {
            switch(p) { case "setup":return "SET UP YOUR CHAT";case "ready":return "READY - PRESS F8 IN WHATSAPP";case "selecting":return "SELECTING";case "loading":return "LOADING OLDER MESSAGES";case "recovering":return "RETRYING IN FOUR SECONDS";case "complete":return "SELECTION COMPLETE";case "review":return "CHECK YOUR SELECTION";case "paused":return "PAUSED - F8 RESUMES IN WHATSAPP";default:return "SESSION ENDED"; }
        }
        void EndSession() {
            if(session!="") { try { File.WriteAllText(Path.Combine(session,"quit.request"),""); } catch(IOException) {} }
            if(closing && worker!=null && !worker.HasExited) { if(!worker.WaitForExit(1500)) worker.Kill(); }
        }
    }
    sealed class GuideForm : Form {
        public GuideForm() {
            Text="ChatSelect - Quick guide"; ClientSize=new Size(566,594); BackColor=Color.FromArgb(247,249,245);
            StartPosition=FormStartPosition.CenterParent; FormBorderStyle=FormBorderStyle.FixedDialog; MaximizeBox=false; MinimizeBox=false;
            Font=new Font("Segoe UI",11); AutoScaleDimensions=new SizeF(96,96); AutoScaleMode=AutoScaleMode.Dpi;
            Controls.Add(new Label {Text="Your first selection",Location=new Point(26,25),Size=new Size(520,43),Font=new Font("Segoe UI",25,FontStyle.Bold),ForeColor=Color.FromArgb(23,48,39)});
            AddStep("01","Open your chat","Scroll to the newest messages. Right-click a message and choose Select messages.",84);
            AddStep("F6","Mark an empty box","Point at the centre of any empty checkbox and press F6. You do not need to click it.",185);
            AddStep("F7","Mark the bottom","Point below the lowest fully visible checkbox, above WhatsApp's toolbar, and press F7.",286);
            AddStep("F8","Start selecting","Keep WhatsApp in front and press F8. Press F8 again to pause; F9 ends the session.",387);
            var done=new Button {Text="Got it",Location=new Point(26,513),Size=new Size(514,46),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(25,111,74),ForeColor=Color.White,Font=new Font("Segoe UI",12,FontStyle.Bold)};
            done.Click+=delegate {Close();}; Controls.Add(done);
        }
        void AddStep(string key,string title,string body,int y) {
            Controls.Add(new Label {Text=key,Location=new Point(26,y),Size=new Size(57,44),TextAlign=ContentAlignment.MiddleCenter,BackColor=Color.FromArgb(224,238,221),ForeColor=Color.FromArgb(25,111,74),Font=new Font("Segoe UI",14,FontStyle.Bold)});
            Controls.Add(new Label {Text=title,Location=new Point(100,y),Size=new Size(440,26),Font=new Font("Segoe UI",13,FontStyle.Bold),ForeColor=Color.FromArgb(23,48,39)});
            Controls.Add(new Label {Text=body,Location=new Point(100,y+32),Size=new Size(440,55),Font=new Font("Segoe UI",11),ForeColor=Color.FromArgb(96,112,104)});
        }
    }
}
