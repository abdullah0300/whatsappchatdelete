﻿param(
    [ValidateRange(1,10000)][int]$TargetCount=1000,
    [double]$LoadWaitSeconds=0.25,
    [ValidateRange(20,200)][int]$ClickGapMs=35,
    [string]$SessionDirectory=$PSScriptRoot,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
public static class TenBoxes {
    // Screenshots are immutable. Read their bytes once instead of calling GDI
    // separately for every pixel inspected by the border and shape checks.
    static Bitmap cachedBitmap;
    static byte[] pixels;
    static int pixelWidth;
    static Color Pixel(Bitmap b,int x,int y) {
        if(!Object.ReferenceEquals(cachedBitmap,b)) {
            int width=b.Width,height=b.Height;
            var data=b.LockBits(new Rectangle(0,0,width,height),
                System.Drawing.Imaging.ImageLockMode.ReadOnly,
                System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            try {
                pixels=new byte[width*height*4];
                for(int row=0;row<height;row++)
                    Marshal.Copy(IntPtr.Add(data.Scan0,row*data.Stride),pixels,row*width*4,width*4);
            } finally { b.UnlockBits(data); }
            pixelWidth=width; cachedBitmap=b;
        }
        int i=(y*pixelWidth+x)*4;
        return Color.FromArgb(pixels[i+2],pixels[i+1],pixels[i]);
    }
    [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
    [DllImport("user32.dll")] static extern bool GetCursorPos(out Point p);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr h,ref Point p);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
    [DllImport("user32.dll")] static extern void mouse_event(uint flags,uint x,uint y,int data,UIntPtr extra);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    public static void Init() { SetProcessDPIAware(); }
    public static bool Down(int key) { return (GetAsyncKeyState(key)&0x8000)!=0; }
    public static Point Mouse() { Point p; GetCursorPos(out p); return p; }
    public static int ClientTop() {
        Point p=new Point(0,0); ClientToScreen(GetForegroundWindow(),ref p); return p.Y;
    }
    public static bool WhatsApp() {
        var s=new StringBuilder(512); GetWindowText(GetForegroundWindow(),s,512);
        return s.ToString().IndexOf("WhatsApp",StringComparison.OrdinalIgnoreCase)>=0;
    }
    public static Bitmap Capture(int x,int y,int w,int h) {
        var b=new Bitmap(w,h);
        using(var g=Graphics.FromImage(b)) g.CopyFromScreen(x,y,0,0,new Size(w,h));
        return b;
    }
    static double Light(Color c) { return (c.R+c.G+c.B)/3.0; }
    static bool Green(Color c) { return c.G>c.R+30 && c.G>c.B+15; }
    public static int GreenCount(Bitmap b,int x,int y,int r) {
        int n=0;
        for(int yy=y-r;yy<=y+r;yy++) for(int xx=x-r;xx<=x+r;xx++)
            if(xx>=0 && yy>=0 && xx<b.Width && yy<b.Height && Green(Pixel(b,xx,yy))) n++;
        return n;
    }
    // Score four straight sides independently. Rounded corners are deliberately excluded.
    public static double Score(Bitmap b,int x,int y,int r) {
        if(x-r-2<0 || y-r-2<0 || x+r+2>=b.Width || y+r+2>=b.Height) return 0;
        if(GreenCount(b,x,y,r-2)>12) return 0;
        double total=0;
        int reach=Math.Max(2,r-3), length=2*reach+1;
        for(int side=0;side<4;side++) {
            int good=0;
            for(int k=-reach;k<=reach;k++) {
                double edge=255;
                for(int d=-1;d<=1;d++) {
                    int xx=x, yy=y;
                    if(side==0) { xx=x-r+d; yy=y+k; }
                    if(side==1) { xx=x+r+d; yy=y+k; }
                    if(side==2) { xx=x+k; yy=y-r+d; }
                    if(side==3) { xx=x+k; yy=y+r+d; }
                    Color c=Pixel(b,xx,yy);
                    int spread=Math.Max(c.R,Math.Max(c.G,c.B))-Math.Min(c.R,Math.Min(c.G,c.B));
                    if(spread<45) edge=Math.Min(edge,Light(c));
                }
                int ix=x, iy=y;
                if(side==0) { ix=x-r+3; iy=y+k; }
                if(side==1) { ix=x+r-3; iy=y+k; }
                if(side==2) { ix=x+k; iy=y-r+3; }
                if(side==3) { ix=x+k; iy=y+r-3; }
                if(edge<215 && Light(Pixel(b,ix,iy))-edge>=20) good++;
            }
            double ratio=(double)good/length;
            if(ratio<0.65) return 0;
            total+=ratio;
        }
        return total/4>=0.78 ? total/4 : 0;
    }
    public static int Calibrate(Bitmap b,int x,int y) {
        return CalibrateLocation(b,x,y)[0];
    }
    public static int[] CalibrateLocation(Bitmap b,int x,int y) {
        double best=0; int radius=0, bx=x, by=y, distance=100;
        for(int r=6;r<=20;r++) for(int dx=-2;dx<=2;dx++) for(int dy=-2;dy<=2;dy++) {
            double score=Score(b,x+dx,y+dy,r);
            int dist=dx*dx+dy*dy;
            if(score>best || (score>0 && score==best && dist<distance)) {
                best=score; radius=r; bx=x+dx; by=y+dy; distance=dist;
            }
        }
        return new int[] {radius,bx,by};
    }
    public static double Recheck(Bitmap b,int x,int y,int radius) {
        double best=0;
        for(int r=Math.Max(6,radius-1);r<=radius+1;r++) best=Math.Max(best,Score(b,x,y,r));
        return best;
    }
    public static Point[] Find(Bitmap b,int column,int top,int bottom,int radius) {
        var result=new List<Point>();
        // Inspect only the two narrow border lanes first. Prefix counts let us
        // find short aligned vertical segments without scoring a square at every pixel.
        var prefix=new int[b.Height+1];
        for(int y=0;y<b.Height;y++) {
            double left=255,right=255;
            for(int d=-3;d<=3;d++) {
                int lx=column-radius+d,rx=column+radius+d;
                if(lx>=0 && lx<b.Width) {
                    Color c=Pixel(b,lx,y);
                    if(Math.Max(c.R,Math.Max(c.G,c.B))-Math.Min(c.R,Math.Min(c.G,c.B))<45)
                        left=Math.Min(left,Light(c));
                }
                if(rx>=0 && rx<b.Width) {
                    Color c=Pixel(b,rx,y);
                    if(Math.Max(c.R,Math.Max(c.G,c.B))-Math.Min(c.R,Math.Min(c.G,c.B))<45)
                        right=Math.Min(right,Light(c));
                }
            }
            Color middle=Pixel(b,column,y);
            bool pair=!Green(middle) && left<215 && right<215 &&
                Light(middle)-left>=20 && Light(middle)-right>=20;
            prefix[y+1]=prefix[y]+(pair?1:0);
        }
        Point bestPoint=Point.Empty; double best=0; int last=-100;
        for(int y=top;y<bottom;y++) {
            int reach=Math.Max(2,radius-3);
            int low=Math.Max(0,y-reach), high=Math.Min(b.Height,y+reach+1);
            if(prefix[high]-prefix[low] < (high-low)*0.5) continue;
            double rowScore=0; int rowX=column;
            for(int dx=-2;dx<=2;dx++) for(int r=Math.Max(6,radius-1);r<=radius+1;r++) {
                double score=Score(b,column+dx,y,r);
                if(score>rowScore) { rowScore=score; rowX=column+dx; }
            }
            if(rowScore>0) {
                if(y-last>radius && best>0) { result.Add(bestPoint); best=0; }
                if(rowScore>best) { best=rowScore; bestPoint=new Point(rowX,y); }
                last=y;
            }
        }
        if(best>0) result.Add(bestPoint);
        return result.ToArray();
    }
    public static void Click(int x,int y) {
        SetCursorPos(x,y); mouse_event(2,0,0,0,UIntPtr.Zero); mouse_event(4,0,0,0,UIntPtr.Zero);
    }
    public static void ScrollUp(int x,int y) {
        SetCursorPos(x,y); mouse_event(0x0800,0,0,600,UIntPtr.Zero);
    }
    public static string Frame(int x,int top,int bottom) {
        var s=new StringBuilder();
        using(var b=Capture(x-25,top,51,bottom-top)) {
            for(int y=0;y<b.Height;y+=4) for(int xx=0;xx<b.Width;xx+=4) {
                Color c=Pixel(b,xx,y);
                s.Append(c.R/16).Append(',').Append(c.G/16).Append(',').Append(c.B/16).Append(';');
            }
        }
        return s.ToString();
    }
}
'@
if ($CheckOnly) { Write-Host 'Timed batch selector compiled.'; exit }
if ($LoadWaitSeconds -le 0) { throw 'LoadWaitSeconds must be positive.' }
[TenBoxes]::Init()
New-Item -ItemType Directory -Path $SessionDirectory -Force | Out-Null
$quitPath=Join-Path $SessionDirectory 'quit.request'
$pausePath=Join-Path $SessionDirectory 'pause.request'
function Write-State {
    param([string]$Phase,[string]$Message)
    $seconds=0.0
    if ($null -ne $activeTimer) { $seconds=$activeTimer.Elapsed.TotalSeconds }
    $state=[pscustomobject]@{
        Phase=$Phase; Message=$Message; Selected=[int]$verified; Target=$TargetCount
        ActiveSeconds=[Math]::Round($seconds,2); UpdatedAt=[DateTime]::UtcNow.ToString('o')
        AutoResumes=[int]$autoResumes
    }
    $state | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $SessionDirectory 'state.tmp') -Encoding UTF8
    Move-Item -LiteralPath (Join-Path $SessionDirectory 'state.tmp') -Destination (Join-Path $SessionDirectory 'state.json') -Force
}
Write-State 'setup' 'Open WhatsApp, enter Select messages mode, then point at an empty checkbox and press F6.'
Write-Host @'
CHATSELECT FOR WINDOWS
Close the older selector first. Open WhatsApp in Select messages mode.
Scroll to the newest messages before calibration.
Use a chat area with several visible empty checkboxes. Keep the window fixed.

F6: Point at the CENTRE of ANY visible EMPTY checkbox and press F6.
F7: Point BELOW the last fully visible checkbox, ABOVE the toolbar, and press F7.
F8: Start. Press F8 again to stop the current test.
F9: Exit immediately.

Counts only boxes that visibly turn green after a click. Maximum: your chosen number of NEW selections.
Selects bottom to top, scrolls UP for older messages, and waits for loading.
Existing selections are skipped. Keep WhatsApp in front and do not move the window.
Clicks up to 5 boxes per batch, then verifies the batch together.
Prints elapsed time and a timing breakdown when stopped.
If a target moves BEFORE clicking, wait 4 seconds and automatically rescan.
F8/F9 or switching away from WhatsApp cancels automatic recovery.
'@
Write-Host "Click gap: $ClickGapMs ms. Batch verification checks every 40 ms."
$column=0; $top=0; $bottom=0; $radius=0; $verified=0
$previous=@{}
$activeTimer=New-Object Diagnostics.Stopwatch
$wallTimer=New-Object Diagnostics.Stopwatch
$scanMs=0.0; $clickMs=0.0; $loadMs=0.0; $scrollCount=0
$autoResumes=0
$script:readyPoints=$null
function Show-Timing {
    $elapsed=$activeTimer.Elapsed
    $average=0.0
    if ($verified -gt 0) { $average=$elapsed.TotalSeconds/$verified }
    Write-Host ('Active time: {0:00}:{1:00}:{2:00} | Wall time: {3:00}:{4:00}:{5:00}' -f [int][Math]::Floor($elapsed.TotalHours),$elapsed.Minutes,$elapsed.Seconds,[int][Math]::Floor($wallTimer.Elapsed.TotalHours),$wallTimer.Elapsed.Minutes,$wallTimer.Elapsed.Seconds)
    Write-Host ('Scan: {0:N1}s | Click + verify: {1:N1}s | Scroll + loading: {2:N1}s | Scrolls: {3}' -f ($scanMs/1000),($clickMs/1000),($loadMs/1000),$scrollCount)
    Write-Host ('Verified: {0} | Average: {1:N2} seconds/message' -f $verified,$average)
}
function Test-Stop {
    return ([TenBoxes]::Down(120) -or [TenBoxes]::Down(119) -or (Test-Path -LiteralPath $quitPath) -or (Test-Path -LiteralPath $pausePath) -or -not [TenBoxes]::WhatsApp())
}
function Wait-AutoResume {
    $recovery=[Diagnostics.Stopwatch]::StartNew()
    while ($recovery.Elapsed.TotalSeconds -lt 4) {
        if (Test-Stop) { return $false }
        Start-Sleep -Milliseconds 50
    }
    return (-not (Test-Stop))
}
function Wait-OlderMessages {
    param([string]$BeforeFrame)
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $next=[double]$LoadWaitSeconds
    $last=''; $stable=0
    while ($timer.Elapsed.TotalSeconds -lt 30) {
        if (Test-Stop) { return $false }
        Start-Sleep -Milliseconds 30
        if ($timer.Elapsed.TotalSeconds -lt $next) { continue }
        $next=$timer.Elapsed.TotalSeconds+0.15
        $frame=[TenBoxes]::Frame($column,$top,$bottom)
        if ($frame -ceq $last) { $stable++ } else { $stable=0 }
        $last=$frame
        if ($stable -ge 2) {
            # An unchanged view may mean that WhatsApp is still fetching a batch.
            # Wait longer in that case; loaded, changed views can continue quickly.
            if ($frame -cne $BeforeFrame) {
                $ready=[TenBoxes]::Capture($column-25,$top,51,$bottom-$top)
                try { $found=@([TenBoxes]::Find($ready,25,0,$ready.Height,$radius) | Sort-Object -Property Y -Descending) }
                finally { $ready.Dispose() }
                if ($found.Count -gt 0) { $script:readyPoints=$found; return $true }
            }
            if ($timer.Elapsed.TotalSeconds -ge 6) { return $true }
        }
    }
    Write-Host 'Stopped: rows are still moving or loading. Wait, then press F8 to resume.'
    return $false
}
while (-not [TenBoxes]::Down(120) -and -not (Test-Path -LiteralPath $quitPath)) {
    foreach ($key in @(117,118,119)) {
        $down=[TenBoxes]::Down($key)
        if ($down -and -not $previous[$key]) {
            if ($key -eq 117) {
                if (-not [TenBoxes]::WhatsApp()) { Write-Host 'Bring WhatsApp to the front first.'; Write-State 'paused' 'Bring WhatsApp to the front. Press F8 there to start or resume.' }
                else {
                    $p=[TenBoxes]::Mouse()
                    $windowTop=[TenBoxes]::ClientTop()
                    [void][TenBoxes]::SetCursorPos($p.X+100,$p.Y)
                    Start-Sleep -Milliseconds 300
                    $sample=[TenBoxes]::Capture($p.X-25,$p.Y-25,51,51)
                    try { $fit=[TenBoxes]::CalibrateLocation($sample,25,25); $radius=$fit[0] } finally { $sample.Dispose() }
                    if ($radius -eq 0) { Write-Host 'No clear EMPTY square found. Try F6 again exactly in its centre.'; Write-State 'setup' 'Box not found. Point at the centre of an EMPTY checkbox and press F6 again.' }
                    else {
                        $column=$p.X+$fit[1]-25; $top=$windowTop; $bottom=0
                        Write-Host 'Column detected.'; Write-State 'setup' 'Checkbox found. Point below the lowest checkbox, above the toolbar, and press F7.'
                    }
                }
            } elseif ($key -eq 118) {
                $bottom=([TenBoxes]::Mouse()).Y
                Write-Host 'Bottom set.'; Write-State 'ready' 'Ready. Keep WhatsApp in front and press F8 to start.'
            } else {
                if ($verified -ge $TargetCount) { Write-Host 'Finished: chosen message count reached. Close this window.' }
                elseif ($radius -eq 0 -or $bottom -le ($top+30)) { Write-Host 'Set F6 and F7 first.'; Write-State 'setup' 'Set the checkbox with F6 and the bottom boundary with F7 first.' }
                elseif (-not [TenBoxes]::WhatsApp()) { Write-Host 'Bring WhatsApp to the front first.'; Write-State 'paused' 'Bring WhatsApp to the front. Press F8 there to start or resume.' }
                else {
                    # Release the start key before treating it as a stop key.
                    while ([TenBoxes]::Down(119) -and -not [TenBoxes]::Down(120)) { Start-Sleep -Milliseconds 30 }
                    $left=$column-25; $height=$bottom-$top
                    $failed=$false; $reviewRequired=$false; $samePage=0; $emptyPages=0
                    $script:readyPoints=$null
                    if (-not $wallTimer.IsRunning) { $wallTimer.Start() }
                    if (Test-Path -LiteralPath $pausePath) { Remove-Item -LiteralPath $pausePath }
                    $activeTimer.Start()
                    Write-State 'selecting' 'Selecting messages. F8 pauses; F9 ends the session.'
                    $runStart=$verified
                    try {
                    Write-Host "Scanning column X=$column, from Y=$top to Y=$bottom, BOTTOM TO TOP."
                    while ($verified -lt $TargetCount -and -not (Test-Stop)) {
                    $phase=[Diagnostics.Stopwatch]::StartNew()
                    if ($null -ne $script:readyPoints) {
                        $points=@($script:readyPoints)
                        $script:readyPoints=$null
                    } else {
                    $scan=[TenBoxes]::Capture($left,$top,51,$height)
                    try {
                        $points=@([TenBoxes]::Find($scan,25,0,$height,$radius) | Sort-Object -Property Y -Descending)
                        # Save only the checkbox column for troubleshooting, without the messages.
                        # Screen images remain in memory and are not saved.
                    } finally { $scan.Dispose() }
                    }
                    $scanMs+=$phase.Elapsed.TotalMilliseconds
                    Write-Host "Found $($points.Count) empty boxes. Selecting from the bottom upward..."
                    if ($points.Count -eq 0) { $emptyPages++ } else { $emptyPages=0 }
                    $interrupted=$false; $refreshRequired=$false
                    for ($offset=0; $offset -lt $points.Count -and $verified -lt $TargetCount; $offset+=5) {
                        if (Test-Stop) { $interrupted=$true; break }
                        $phase=[Diagnostics.Stopwatch]::StartNew()
                        $size=[Math]::Min(5,[Math]::Min($points.Count-$offset,$TargetCount-$verified))
                        $batch=@($points[$offset..($offset+$size-1)])
                        # One fresh strip checks every target before the batch begins.
                        $preflight=[TenBoxes]::Capture($left,$top,51,$height)
                        try {
                            foreach ($p in $batch) {
                                if ([TenBoxes]::Recheck($preflight,$p.X,$p.Y,$radius) -eq 0) {
                                    $refreshRequired=$true; break
                                }
                            }
                        } finally { $preflight.Dispose() }
                        if ($refreshRequired) {
                            Write-Host 'Target moved before clicking. Restarting from a fresh scan in 4 seconds; F8 cancels.'; Write-State 'recovering' 'Messages moved. Waiting four seconds, then trying a fresh scan.'
                            $clickMs+=$phase.Elapsed.TotalMilliseconds
                            break
                        }
                        $clicked=New-Object 'System.Collections.Generic.List[System.Drawing.Point]'
                        foreach ($p in $batch) {
                            if (Test-Stop) { $interrupted=$true; break }
                            [TenBoxes]::Click($left+$p.X,$top+$p.Y)
                            $clicked.Add($p)
                            $gap=[Diagnostics.Stopwatch]::StartNew()
                            while ($gap.ElapsedMilliseconds -lt $ClickGapMs) {
                                if (Test-Stop) { $interrupted=$true; break }
                                Start-Sleep -Milliseconds 5
                            }
                            if ($interrupted) { break }
                        }
                        [void][TenBoxes]::SetCursorPos($column+100,[int](($top+$bottom)/2))
                        $confirmed=0; $checkTimer=[Diagnostics.Stopwatch]::StartNew()
                        while ($clicked.Count -gt 0 -and $checkTimer.Elapsed.TotalSeconds -lt 3) {
                            if ([TenBoxes]::Down(120) -or -not [TenBoxes]::WhatsApp()) { $interrupted=$true; break }
                            Start-Sleep -Milliseconds 40
                            $after=[TenBoxes]::Capture($left,$top,51,$height)
                            try {
                                $confirmed=0
                                foreach ($p in $clicked) {
                                    if ([TenBoxes]::GreenCount($after,$p.X,$p.Y,$radius) -ge 30) { $confirmed++ }
                                }
                            } finally { $after.Dispose() }
                            if ($confirmed -eq $clicked.Count) { break }
                        }
                        $verified+=$confirmed
                        Write-State 'selecting' 'Selecting messages. F8 pauses; F9 ends the session.'
                        $clickMs+=$phase.Elapsed.TotalMilliseconds
                        Write-Host ('Verified {0} | Batch {1}/{2} | Active {3:N1}s' -f $verified,$confirmed,$clicked.Count,$activeTimer.Elapsed.TotalSeconds)
                        if ($confirmed -ne $clicked.Count) {
                            $failed=$true
                            Write-Host 'Stopped: batch was not fully verified. No retry clicks were made. Review the selection.'; $reviewRequired=$true
                        }
                        if ($failed -or $interrupted) { break }
                    }
                    if ($failed -or $interrupted -or $verified -ge $TargetCount -or (Test-Stop)) { break }
                    if ($refreshRequired) {
                        $phase=[Diagnostics.Stopwatch]::StartNew()
                        $resume=Wait-AutoResume
                        $loadMs+=$phase.Elapsed.TotalMilliseconds
                        if (-not $resume) { break }
                        $autoResumes++
                        $script:readyPoints=$null
                        Write-Host "Automatically resuming with new checkbox positions. Verified $verified/$TargetCount."
                        # Stay on this page and discard all old coordinates.
                        continue
                    }
                    if ($emptyPages -ge 8) {
                        Write-Host 'Stopped: no empty boxes found across 8 scans. Review the chat before resuming.'
                        break
                    }
                    $beforeScroll=[TenBoxes]::Frame($column,$top,$bottom)
                    if (Test-Stop) { break }
                    $phase=[Diagnostics.Stopwatch]::StartNew()
                    $scrollCount++
                    [TenBoxes]::ScrollUp($column+100,[int](($top+$bottom)/2))
                    Write-Host 'Scrolling up: checking for ready boxes; waiting longer only if needed...'; Write-State 'loading' 'Scrolling up and waiting for older messages.'
                    $loaded=Wait-OlderMessages -BeforeFrame $beforeScroll
                    $loadMs+=$phase.Elapsed.TotalMilliseconds
                    if (-not $loaded) { break }
                    $afterScroll=[TenBoxes]::Frame($column,$top,$bottom)
                    if ($afterScroll -ceq $beforeScroll) { $samePage++ } else { $samePage=0 }
                    if ($samePage -ge 3) {
                        Write-Host 'Stopped: scrolling did not change the view after 3 attempts. You may be at the start of the chat.'
                        break
                    }
                    }
                    } finally {
                        $activeTimer.Stop()
                        if ($verified -ge $TargetCount) { Write-State 'complete' 'Finished. Review your selected messages in WhatsApp.' }
                        elseif ($reviewRequired) { Write-State 'review' 'A click could not be verified. Review the selected messages before pressing F8 to resume.' }
                        else { Write-State 'paused' 'Paused. Keep WhatsApp in front and press F8 to resume. F6 and F7 recalibrate if the window moved.' }
                        Show-Timing
                        $timing=[pscustomobject]@{
                            Version='ChatSelect-1.0-beta'; Target=$TargetCount; ClickGapMs=$ClickGapMs; BatchSize=5
                            AutoResumes=$autoResumes
                            Verified=$verified; NewThisRun=($verified-$runStart)
                            ActiveSeconds=[Math]::Round($activeTimer.Elapsed.TotalSeconds,2)
                            WallSeconds=[Math]::Round($wallTimer.Elapsed.TotalSeconds,2)
                            ScanSeconds=[Math]::Round($scanMs/1000,2)
                            ClickVerifySeconds=[Math]::Round($clickMs/1000,2)
                            ScrollLoadSeconds=[Math]::Round($loadMs/1000,2)
                            Scrolls=$scrollCount
                        }
                        $timing | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $SessionDirectory 'Last-timing.json') -Encoding UTF8
                    }
                    Write-Host "Test stopped. $verified / $TargetCount verified new selections. Review WhatsApp."
                    if ($verified -lt $TargetCount) { Write-Host 'F8 resumes. If the window moved, set F6 and F7 again first.' }
                    while ([TenBoxes]::Down(119) -and -not [TenBoxes]::Down(120)) { Start-Sleep -Milliseconds 30 }
                    $down=$false
                }
            }
        }
        $previous[$key]=$down
    }
    Start-Sleep -Milliseconds 50
}
Write-Host "Exited. Verified selections: $verified / $TargetCount."


if ($verified -ge $TargetCount) { Write-State 'complete' 'Finished. Review your selected messages in WhatsApp.' } else { Write-State 'stopped' 'Session ended. Review the selected messages in WhatsApp.' }
