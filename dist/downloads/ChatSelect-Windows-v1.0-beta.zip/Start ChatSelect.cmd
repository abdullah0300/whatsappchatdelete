@echo off
start "" "%~dp0ChatSelect.exe"
